
#lista de futas
frutas =["pera","mango","lulo", "fresa"]# comienza 0,1,2
print(frutas[-1]) # -1 indica el ultimo registro de la lista

#lista mixta
mixta = [1, "juan",2, "miguel" ,3, "laura", 4, "camila"]
print(mixta[0])# imprime el primero
print(mixta[-1])# imprime el ultimo
print(mixta[3])# imprime el cuarto
print(mixta[2])# imprime el tercero
print(mixta[4])# imprime el quinto
print(mixta[1:5]) # imprime desde el indice 1 hasta el 4, el 5 no lo incluye


frutas=["lulo","mango","piña","fresa","guama","marañon"]
print(frutas[1:4]) # imprime desde el indice 1 hasta el 3, el 4 no lo incluye
