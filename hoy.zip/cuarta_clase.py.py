

palabra="python"
for letra in palabra:
    print(letra, end = "")

numero=int(input("digite el numero hasta donde quieres que llegue tu secuencia: "))
for x in range(numero):
    print(x)

print("=*80")

print("bucle while")
          
contador=0
while contador<10.24:
    contador=float(input("digite el numero "))
    print(contador)
    contador+=0.12

cont=20
while cont>0:
        print(cont, end=" ")
        cont-=1

print("\n imprime los numeros de 5 en 5 hasta 50 \n")
cadena=100
51
i=0
while i < cadena:
        if i % 5 ==0:
                print(i)
        i+=1



numero = int(input("ingresa un numero: "))
if numero % 2 == 0: 
    print("el numero es par")
else:
    print("el numero es impar")




