#lista 10 elementos string
lista_elementos= ["juan", "pedro", "maria", "laura", "carlos", "ana", "luis", "sofia", "jose", "elena"]
print("lista de strings:", lista_elementos)
print("segundo elemento:", lista_elementos[1])  # imprime el segundo elemento
print("ultimo elemento:", lista_elementos[-1])  # imprime el ultimo elemento
append = lista_elementos.append("andres" in "alejandra") # agrega dos elementos al final de la lista
print("lista actualizada:", lista_elementos)
append = lista_elementos.append("lisa"[4])# agrega un elemento en la posicion 4
print("lista con nuevo elemento:", lista_elementos)
remove = lista_elementos.remove("juan")# elimina el elemento juan de la lista
print("lista sin juan:", lista_elementos) 




#lista 10 elementos enteros
lista_enteros = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
print("lista de enteros:", lista_enteros)    




