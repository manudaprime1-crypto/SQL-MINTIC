
# Par - impar
numero = int(input("ingresa un numero: "))
if numero % 2 == 0: # si el numero es divisible entre 2
    print("el numero es par")
else: # si no es divisible entre 2
    print("el numero es impar")
    
# Saludo nombre y nota
nombre = input("ingresa tu nombre: ") # input para nombre
print("Hola", nombre) 
output = ("Hola " + nombre)# concatenacionse unen las cadenas de texto
nota = float(input("ingresa tu nota rango 1.0 a 5.0: "))
if not(1.0 <= nota <= 5.0):
    print("nota fuera de rango")
elif nota >= 3.0:
    print("Aprobado")
else:
    print("Reprobado")

# laLongitud de triangulos
    lado1 = float(input("triangulo 1: ")) 
    lado2 = float(input("triangulo 2: "))
    lado3 = float(input("triangulo 3: "))
    if lado1 == lado2 == lado3: # si los tres lados son iguales
        print("triangulo equilatero")
    elif lado1 == lado2 or lado1 == lado3 or lado2 == lado3: # si dos lados son iguales
        print("triangulo isosceles")
    else: # si ningun lado es igual
        print("triangulo escaleno")

# mensaje y contador cadena de caracteres y espacios
mensaje = input("ingresar mensaje: ")
contador = 0 # contador de caracteres
for caracter in mensaje: # recorre cada caracter en el mensaje
    if caracter in "mensaje": # si el caracter esta en mensaje
        contador += 1 # incrementa el contador
print("El mensaje tiene", len(mensaje), "caracteres")

# tabla de multiplicar
numero = int(input("ingresa un numero: "))
for i in range(1, 11): # rango de 1 a 10 se multiplica
    resultado = numero * i # Multiplicacion en secuencia 
    print(numero, "x", i, "=", resultado)


contar = 0 # inicia el conteo
while contar <= 10: #termina el conteo
    print("contar")
    contar += 1 #aumenta el conteo
    
    

 













