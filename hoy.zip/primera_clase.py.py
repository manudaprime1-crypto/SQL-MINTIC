nombre = "luis carlos"
edad = 23
estatura = 1.72
estudiante = True
print("el nombre es un tipo de dato", type(nombre))
print("la edad es un tipo de dato", type(edad))
print("la estatura es un tipo de dato", type(estatura))
print("el estudiante es un tipo de dato", type(estudiante))

print("=" * 60)
print("OPERADORES ARITMETICOS")
a=23
b=5
suma= a+b
resta = a - b
multiplicacion = a * b  
division = a / b
print(f"la suma de {a} + {b} es {suma}")
print(f"la resta de {a} - {b} es {resta}")
print(f"la multiplicacion de {a} * {b} es {multiplicacion}")
print(f"la division de {a} / {b} es {division}")
print(f"la division entera de {a} // {b} es {a // b}")
print(f"el resto de la division de {a} % {b} es {a % b}")
print(f"el exponente de {a} ** {b} es {a ** b}")

print("OPERADORES DE COMPARACION")

print("IGUAL A ESE ==", a == b)
print("DIFERENTE A ESE !=", a != b)
print("MAYOR QUE ESE >", a > b)
print("MENOR QUE ESE <", a < b)

print("OPERADORES LOGICOS")

RESULTADO_AND = "azul" and "azul" =="azul"
print("El resultado de AND es", RESULTADO_AND)
RESULTADO_OR = "azul" or "rojo" == "azul"
print("El resultado de OR es", RESULTADO_OR)
RESULTADO_NOT = not "azul" == "rojo"
print("El resultado de NOT es", RESULTADO_NOT)
print("=" * 60)

print("input y output")

ingresar_nombre = input("digita tu nombre: ")
print(f"¡hola; ", ingresar_nombre)
ingresar_edad = int(input("ingresa tu tu edad: "))
print(f"tu edad es: {ingresar_edad}")
ingresar_estatura = input("ingresa tu estatura: ")
print(f"tu estatura es: {ingresar_estatura}")   




















