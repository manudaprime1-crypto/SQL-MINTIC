#ejercicio practico 1 = encontrar numeros en una lista

"""lista_numeros = [10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100]
print("numero mayor:", max(lista_numeros))# max() muestra el valor mayor de la lista
print("numero menor:", min(lista_numeros))# min() muestra el valor menor de la lista
print("suma de todos los numeros:", sum(lista_numeros))# sum() suma todos los valores de la lista
print("cantidad de numeros en la lista:", len(lista_numeros))# len() muestra la cantidad de elementos en la lista
       

#ejercicio practico 2 = filtrar numeros pares e impares 
numeros =[5,9,2,7,3,6,4,1,8,10]
numeros.sort()# ordena la lista de menor a mayor
for numero in numeros:
    if numero % 2 == 0:
        print(f"{numero} numero par")
    else:
        print(f"{numero} numero impar")"""

    #ejercicio practico 3 = lISTA INGRESADO POR USUARIO

lista_usuario = []# lista vacia 
numero_usuario = int(input("ingresa un numero: "))# input para ingresar numeros 
while numero_usuario != -1: # mientras el numero ingresado sea diferente de -1
    append = lista_usuario.append(numero_usuario) # agrega el numero a la lista  
    



