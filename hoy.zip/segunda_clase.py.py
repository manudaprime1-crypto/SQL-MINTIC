longitud = 4
area = longitud ** 2
print("area del cuadrado es" ,area)

print("=" * 60)

ingresar_numero = int(input("ingresa numero "))
rango = 1<= ingresar_numero <= 20
print("rango validado" ,rango)

print("=" * 60)

camisas = int(input("cantidad_camisas "))
pantalones = int(input("cantidad_pantalones"))
total_ventas = camisas + pantalones
print(total_ventas)

print("=" * 60)

base = int(input("base rectangulo "))
altura = int(input("altura rectanculo "))
area = base * altura
print("el area del rectangulo es", area)

print("=" * 60)


venta = int(100000)
descuento =  int(0.20 * venta)
venta_total = venta - descuento
print("el valor total de la venta es", venta_total)


print("=" * 60)



nota_1 = int(input("ingresa nota 1: "))
nota_2 = int(input("ingresa nota 2: "))
nota_3 = int(input("ingresa nota 3: "))
promedio = (nota_1 + nota_2 + nota_3) / 3   
print("el promedio es", promedio)












  














