edad = int(input("digita tu edad"))
if edad >= 18:
    print("mayor de edad ") 
else:
    print("menor de edad ")


print("=" * 60)



numero = int(input("digite un numero "))
if numero < 10:
    print("el numero es negativo")
elif numero > 10:
    print("el numero es negativo")
else:
    print("el numero es igual a cero")



print("=" * 60)


nota_1 = int(input("ingresa nota 1: "))
nota_2 = int(input("ingresa nota 2: "))
nota_3 = int(input("ingresa nota 3: "))
promedio = (nota_1 + nota_2 + nota_3) / 3   
print("el promedio es", promedio)
if promedio >= 4:
    print("exelente")
elif promedio < 4 and promedio >=3:
    print("bueno")
elif promedio < 3 and promedio > 0:
    print("deficiente")
else:
    print("malo")
    




    
